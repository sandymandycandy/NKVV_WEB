document.querySelector('form').addEventListener('submit', async (e) => {
  e.preventDefault();

  const fullName = document.querySelector('#fullName').value;
  const email = document.querySelector('#email').value;
  const password = document.querySelector('#password').value;

  const response = await fetch('/api/signup', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ fullName, email, password })
  });

  const result = await response.json();
  alert(result.message || result.error);
});
