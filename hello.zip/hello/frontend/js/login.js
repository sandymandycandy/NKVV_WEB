document.querySelector('form').addEventListener('submit', async (e) => {
  e.preventDefault();

  const email = document.querySelector('#email').value;
  const password = document.querySelector('#password').value;

  try {
    const response = await fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });

    const result = await response.json();

    // ✅ Step 4: Use the redirection URL provided by the backend
    if (result.success) {
      // Automatically redirect to the correct dashboard (vendor or buyer)
      window.location.href = result.redirectTo;
    } else {
      // Display error if login fails
      alert(result.error || result.message || 'Login failed');
    }

  } catch (error) {
    console.error('Login error:', error);
    alert('An unexpected error occurred. Please try again.');
  }
});
