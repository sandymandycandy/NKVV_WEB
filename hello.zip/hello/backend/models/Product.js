// models/Product.js
const mongoose = require('mongoose');

const ProductSchema = new mongoose.Schema({
    name: { type: String, required: true, trim: true },
    description: { type: String, trim: true },
    category: { type: String, required: true },
    price: { type: Number, required: true, min: 0 },
    unit: { type: String, required: true }, // Added 'unit' field
    stock: { type: Number, required: true, min: 0 },
    vendor: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }, // Link to the vendor user
    imageUrl: { type: String, default: '/default-product.png' }, // For product image
    isAvailable: { type: Boolean, default: true },
    createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Product', ProductSchema);