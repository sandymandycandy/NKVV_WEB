const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const path = require('path');
const connectDB = require('./config/db');
const authRoutes = require('./routes/authRoutes');
const productRoutes = require('./routes/productRoutes');

// Initialize environment variables
dotenv.config();

// Initialize app
const app = express();

// Connect to MongoDB
connectDB();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend')));

// API routes
app.use('/api', authRoutes);
app.use('/api', productRoutes);

// --- Frontend HTML Routes ---

// Login and Signup
app.get('/', (_, res) =>
  res.sendFile(path.join(__dirname, '../frontend/login.html'))
);

app.get('/signup.html', (_, res) =>
  res.sendFile(path.join(__dirname, '../frontend/signup.html'))
);

// Buyer Dashboard Pages
app.get('/buyer-dashboard', (_, res) =>
  res.sendFile(path.join(__dirname, '../frontend/buyer-dashboard.html'))
);

app.get('/buyer/products', (_, res) =>
  res.sendFile(path.join(__dirname, '../frontend/product-listing.html'))
);

app.get('/buyer/cart', (_, res) =>
  res.sendFile(path.join(__dirname, '../frontend/my-cart.html'))
);

app.get('/buyer/profile', (_, res) =>
  res.sendFile(path.join(__dirname, '../frontend/buyer-profile.html'))
);

// Placeholder Buyer Pages (for sidebar links)
app.get('/buyer/history', (_, res) =>
  res.sendFile(path.join(__dirname, '../frontend/buyer-history.html'))
);
app.get('/buyer/chat', (_, res) =>
  res.sendFile(path.join(__dirname, '../frontend/buyer-chat.html'))
);


// Vendor Dashboard Pages
app.get('/vendor-dashboard', (_, res) =>
  res.sendFile(path.join(__dirname, '../frontend/vendor-dashboard.html'))
);

app.get('/vendor/products', (_, res) =>
  res.sendFile(path.join(__dirname, '../frontend/vendor-products.html'))
);

app.get('/vendor/orders', (_, res) =>
  res.sendFile(path.join(__dirname, '../frontend/vendor-orders.html'))
);

app.get('/vendor/profile', (_, res) =>
  res.sendFile(path.join(__dirname, '../frontend/vendor-profile.html'))
);

app.get('/vendor/add-product', (_, res) =>
  res.sendFile(path.join(__dirname, '../frontend/vendor-add-product.html'))
);

// ✅ ADDED: Serve the vendor's "Inventory" page
app.get('/vendor/inventory', (_, res) =>
  res.sendFile(path.join(__dirname, '../frontend/vendor-inventory.html'))
);

// Placeholder Vendor Pages (for sidebar links)
app.get('/vendor/notifications', (_, res) =>
  res.sendFile(path.join(__dirname, '../frontend/vendor-notifications.html'))
);
app.get('/vendor/chat', (_, res) =>
  res.sendFile(path.join(__dirname, '../frontend/vendor-chat.html'))
);


// Fallback route
app.use((req, res) => {
  res.status(404).send('Page not found');
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () =>
  console.log(`🚀 Server running on http://localhost:${PORT}`)
);