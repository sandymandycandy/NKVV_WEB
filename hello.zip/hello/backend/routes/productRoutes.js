// routes/productRoutes.js
const express = require('express');
const router = express.Router();
const productController = require('../controllers/productController');
const protect = require('../middleware/authMiddleware'); // ✅ Import JWT middleware

// ✅ Route to add a new product (POST request)
// URL: /api/vendor/products
router.post('/vendor/products', protect, productController.createProduct);

// ✅ Route to get all products for a specific vendor (GET request)
// URL: /api/vendor/my-products
router.get('/vendor/my-products', protect, productController.getVendorProducts);

// (You can add more product-related routes like /products/:id or updateProduct here)

module.exports = router;
