const express = require('express');
const router = express.Router();
const User = require('../models/User');

// 👉 Signup Route
router.post('/signup', async (req, res) => {
  const { name, email, password, role } = req.body;

  if (!name || !email || !password || !role) {
    return res.status(400).json({ success: false, error: 'All fields are required' });
  }

  try {
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(409).json({ success: false, error: 'User already exists' });
    }

    const user = new User({ name, email, password, role });
    await user.save();

    res.status(201).json({ success: true, message: 'User created successfully' });
  } catch (err) {
    console.error('Signup error:', err);
    res.status(500).json({ success: false, error: 'Internal server error' });
  }
});

// 👉 Login Route
router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ success: false, error: 'Email and password are required' });
  }

  try {
    const user = await User.findOne({ email });

    // Check if user exists and if password matches
    if (!user || user.password !== password) {
      return res.status(401).json({ success: false, error: 'Invalid email or password' });
    }

    // ✅ Determine redirection based on user role
    let redirectTo;
    if (user.role === 'vendor') {
      redirectTo = '/vendor-dashboard';
    } else if (user.role === 'buyer') {
      redirectTo = '/buyer-dashboard';
    } else {
      redirectTo = '/home'; // fallback if role is unknown
    }

    // Send login success response with redirection info
    res.status(200).json({
      success: true,
      message: 'Login successful',
      redirectTo
    });

  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ success: false, error: 'Internal server error' });
  }
});

module.exports = router;
