// controllers/productController.js
const Product = require('../models/Product');
const User = require('../models/User');

// ✅ Create a new product
exports.createProduct = async (req, res) => {
  try {
    const vendorId = req.user.id; // ✅ Use authenticated vendor ID

    const { name, description, category, price, unit, stock } = req.body;

    // Basic validation
    if (!name || !description || !category || !price || !unit || stock === undefined) {
      return res.status(400).json({ success: false, error: 'All product fields are required.' });
    }

    const newProduct = new Product({
      name,
      description,
      category,
      price,
      unit,
      stock,
      vendor: vendorId
      // imageUrl: '/default-product.png'
    });

    await newProduct.save();

    res.status(201).json({
      success: true,
      message: 'Product added successfully!',
      data: newProduct
    });

  } catch (err) {
    console.error('Error creating product:', err);
    if (err.name === 'ValidationError') {
      const messages = Object.values(err.errors).map(val => val.message);
      return res.status(400).json({ success: false, error: `Validation Error: ${messages.join(', ')}` });
    }
    res.status(500).json({ success: false, error: 'Failed to add product. Server error.' });
  }
};

// ✅ Get products for a specific vendor
exports.getVendorProducts = async (req, res) => {
  try {
    const vendorId = req.user.id; // ✅ Use authenticated vendor ID

    const products = await Product.find({ vendor: vendorId });

    res.status(200).json({
      success: true,
      data: products
    });

  } catch (err) {
    console.error('Error fetching vendor products:', err);
    res.status(500).json({ success: false, error: 'Failed to fetch products.' });
  }
};
